import UIKit

var dict = ["Pi":3.14, "Gravity":9.8]

for (k,v) in dict{
    
    print("Key: \(k), Value:\(v)")
    
}



/*
 Class definition
 */

class Shape
{
    
    var title = "shape"
    
    func area() -> Double{
        
        return 0.0
        
    }
    
    func description()->String{
        
        return "Title: \(title), Area: \(area())"
        
    }
    
    
}

class Circle: Shape
{
    
    var radius = 0.0
    
    func diameter()-> Double
    {
        return 2*radius
    }
    
    func circumfrence() -> Double
    {
        return diameter()*Double.pi
    }
    
    override func area()-> Double
    {
        return Double.pi * radius * radius
    }
}

let c1 = Circle()

print("Radius: \(c1.radius), Circumfrence: \(c1.circumfrence()), Area: \(c1.area())")

c1.radius = 5.0
print("Radius: \(c1.radius), Circumfrence: \(c1.circumfrence()), Area: \(c1.area())")

let c2 = Circle()
c2.radius = 10.0

let c3 = c1
if c1 !== c2
{
    print("c1 and c2 are not identical")
}
else
{
    print("c1 and c2 are identical")
}
if c1 === c3
{
    print("c1 and c3 are identical")
}

c1.title = "Circle One"
c2.title = "Circle Two"
print(c1.description())
print(c2.description())
print(c2.description())

c3.title = "Circle Three"
print(c1.description())
print(c2.description())
print(c2.description())


class Sphere: Circle
{
    func volume() -> Double
    {
        return (4.0 * super.area() * super.radius) / 3.0
    }
    
    override func area() -> Double
    {
        return 4.0 * super.area()
    }
    
    override func description() -> String {
        return super.description() + ", Volume: \(self.volume())"
    }
}

let s1 = Sphere()
s1.title = "Sphere One"
s1.radius = 2.0
print(s1.description())

func printDesc(_ shape : Shape)
{
    
    print(shape.description())
    
}

printDesc(c1)
printDesc(s1)

//Initialization

class Celsius
{
    
    var temp: Double
    
    init(celsius: Double)
    {
        temp = celsius
    }
    
    init(farenheit: Double)
    {
        temp = (farenheit - 32.0)/1.8
    }
    
}

var freezingPoint = Celsius(farenheit: 32.0)
print(freezingPoint.temp)

var boilingPoint = Celsius(celsius: 100.0)
print(boilingPoint.temp)

class Rectangle: Shape
{
    var sideA, sideB : Double
    
    init(a: Double, b:Double) {
        sideA = a
        sideB = b
        
    }
    
    override func area() -> Double {
        return sideA * sideB
    }
    
    func parimeter()->Double
    {
        return (2*sideA)+(2*sideB)
    }
    
    override func description() -> String {
        return super.description() + ", Parimeter: \(self.parimeter())"
    }
    
}
