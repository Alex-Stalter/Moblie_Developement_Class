import UIKit
/*
 Arrays
 */

var intArray: [Int] = [] //declare and initialize as an empty array
var intArray1 = [Int]()
var intArray2: [Int] //declare
intArray2 = [5,4,1,2,3] //initilization
var intArray3 = [1,3,5] // declare and initilization
var intArray4 = intArray3
intArray3 = [5,6] //value can be changed
print(intArray3)

var A = Array(1...10)
var B = Array(repeating: 0.5, count: 100)

intArray3.append(10)
print(intArray3)

for i in intArray3{
    
    print(i)
    
}


var strArray: [String]
strArray = ["Mon", "Tue"]
strArray.append("Thu")
strArray += ["Fri", "Sat", "Sun"]
strArray.insert("Wed", at: 2)
strArray.remove(at: 5)
strArray.removeLast()
//strArray.reversed()
print(strArray)
//strArray.sort()

print("Str Count: \(strArray.count)")

for d in strArray{
    print(d)
}

for i in 0..<strArray.count{
    strArray[i] += " day"
    print("Str \(i): \(strArray[i])")
    
}

if let i = strArray.firstIndex(of: "Tue day"), let j = strArray.firstIndex(of: "Thu day"){
    
    strArray[i] += ": COMP399"
    strArray[j] += ": COMP399"
}

print(strArray)

/*
 Dictionaries: declaration, initilization, methods
 */
var newDiction = [String: Double]()
var newDiciton1: [String: Double] = [:]
var diction = ["PI": 3.14, "Gravity": 9.8]
diction["Gravity"] = 9.0
diction["Gravity"] = nil
diction["Gravity"] = 9.8
diction.removeValue(forKey: "Gravity")
diction["e"] = 2.718
var values = Array(diction.values)
var keys = Array(diction.keys)
for i in 0..<keys.count{
    print("Value: \(values[i]), Key: \(keys[i])")
}

/*
 Switch
 */

let grade = arc4random_uniform(101) //generate a random int from [0, 100] upper bound value is excluded
switch grade{
    
case 90...100:
    print("A")
    
case 80...89,70...79:
    print("B or C")

case 60...69:
    print("D")
default:
    print("F")
}
