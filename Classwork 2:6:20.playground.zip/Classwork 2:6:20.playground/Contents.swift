import UIKit

/*
 Function: Defition
 */

func printGreeting(){
    print("Welcome!")
}

printGreeting()

func printMsg(msg: String, numOfTimes: Int){ //parameters are the terms when the fucntion is defined
    
    for _ in 1...numOfTimes
    {
    print(msg)
    }
}

printMsg(msg: "COMP399", numOfTimes: 3) //arguments are the terms used when the function is called

//omit argument label by using _
func printMsg2(_ msg:String, numOfTimes: Int){
    
    for _ in 1...numOfTimes{
        print(msg)
    }
}

printMsg2("Comp399", numOfTimes: 2)

//Can define default value for the parameters bu assging a vlaue to the parameter afther tha tdate a type

func printMsg3(_ msg: String, numOfTimes: Int = 3){
    for _ in 1...numOfTimes{
        print(msg)
    }
}

printMsg3("COMP399")
print("COMP399", terminator: " ")
print("COMP435")

func printGreeting(name: String, from hometown: String){
    
    let greeting = "Welcome " + name + " who comes from " + hometown
    print(greeting)
    
    
}

printGreeting(name: "Alex", from: "Acushnet")

func sumNum(from a: Int, to b: Int){
    
    var sum = 0
    for i in a...b{
        sum += i
    }

    print("The sum is: \(sum)")
    
}

sumNum(from: 1, to: 10)
//Pass a carying number of iinput values when the function is called by adding ... after the type
//One function can only have one such kind of parameter (Varaidic parameter)
func printAverage(_ numbers: Double...){
    
    var total = 0.0
    for n in numbers{
        total += n
    }
    let avg = total/Double(numbers.count)
    print("The average is : \(avg)")
}

printAverage(1,2,3,4,5,6,7,8,9)

func coursename(prefix: String, number: Int) -> String{
    return prefix + String(number)
}

print(coursename(prefix: "COMP", number: 399))

//return multiple values

func minMax(_ array: [Int]) ->(min: Int, max: Int)?{
    
    if array.isEmpty{
        return nil
    }
    var tMin = array[0]
    var tMax = array[0]
    
    for v in array
    {
        if v<tMin{
            tMin = v
        }
        if v>tMax{
            tMax = v
        }
    }
    
    return (tMin, tMax)
    
}

let bounds = minMax([1,3,0,7])!
print("Min is \(bounds.min) and Max is \(bounds.max)")

func minMax2(_ array: [Int]) -> (min: Int, max: Int)?
{
    if array.isEmpty    {return nil}
    var tMin = array[0]
    var tMax = array[0]
    for v in array
    {
        if v < tMin
        {
            tMin = v
        }
        if v > tMax
        {
            tMax = v
        }
    }
    
    return (tMin, tMax)
}

if let bounds1 = minMax2([1,3,0]) //error since array is empty
{
    print("Min is \(bounds1.min) and max is \(bounds1.max)")
}
else
{
    print("nil is provided")
}

if let bounds1 = minMax2([]) //error since array is empty
{
    print("Min is \(bounds1.min) and max is \(bounds1.max)")
}
else
{
    print("nil is provided")
}

var bounds2 = minMax2([1,2,3])
print("Min \(bounds2!.min), Max: \(bounds2!.max)")

/*var bounds3 = minMax2([])
  print("Min \(bounds3!.min), Max: \(bounds3!.max)")
*/

/*
 In-Out parameters
 */

func swapTwoNum( n1: inout Int, n2: inout Int){
    
    let t = n1
    n1=n2
    n2=t
}
var x = 10
var y = 20

swapTwoNum(n1: &x, n2: &y)
print("(\(x),\(y))")

/*
 Function Type: cana be used as regualr type to define var or let constant
 
 a different function with the same matching types can be assigned to the same variable
 */
func addTwoInts(_ a : Int, _ b: Int) -> Int{
    
    return a+b
}

var sum = addTwoInts(5, 98)
print(sum)

func multipleTwoInts(_ a:Int, _ b: Int) -> Int
{
    
    return a*b
    
}

var mathFunc: (Int,Int) -> Int = addTwoInts

print("MathFunc result: \(mathFunc(2,3))")

mathFunc = multipleTwoInts
print("MathFunc result: \(mathFunc(2,3))")

let anotherMathFunc = addTwoInts

//define a function as a print math result

func printMathResult(_ mathFunc:(Int,Int)->Int,_ a: Int,_ b: Int)
{
    
    print("Math Results: \(mathFunc(a,b))")
    
}

printMathResult(addTwoInts, 1, 3)
printMathResult(multipleTwoInts, 1, 3)

func stepForward(_ input: Int) -> Int
{
    
    return input+1
    
}

func stepBack(_ input: Int) -> Int
{
    
    return input-1
    
}

func controlFunction(backward: Bool)-> (Int)->Int
{
    
    return backward ? stepBack : stepForward
    
}

var currentValue = -3

let moveToZero = controlFunction(backward: currentValue>0)
print("Couting to zero")
while currentValue != 0{
    
    print("\(currentValue)")
    currentValue = moveToZero(currentValue)
    
}

