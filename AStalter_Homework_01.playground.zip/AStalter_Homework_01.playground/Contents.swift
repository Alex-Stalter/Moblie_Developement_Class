/*
 Author: Alex Stalter
 Date: 1/30/2020
 Class: COMP 399-001 Mobile App Developement
 
 The purpose of this code is to preform three functions on a given dictionary
 the three functions in this code include finding lowest value of an item in the list, highest value of an itme in the list, and
 finally finding the average value of all items in the list.
 
 */
import UIKit
/*The variable products is the dictionary declared as a global variable so ti can be accessed by
  all of the functions without needing to be passed in.
 */

var products: [String:Double] = ["Ice Cream":5.0,"Pizza":3.0,"Burger":3.5,"Fries":1.5,"Soda":1.0]
/*
 The dictFunc takes in a input of a string to determine what sort of operation it is required to preform on the
 products dictionary.
 */
func dictFunc(work:String){
    //Declaration of all variables needed to print out results required by user.
    //lowestValue is a double that is used as a comparison to the current itme being inspected and at the end of the function will be printed.
    var lowestValue:Double = 100
    //lowestKey holds the string description of the item with the lowest current value and is only used to be printed to the screen.
    var lowestKey:String = ""
    
    //highestValue is a double that is used as a comparison for each itme inspected and the lagest value will be stored here to be printed.
    var highestValue:Double = 0
    //highestKey holds the string value of the higest current item and is used to print out to the screen.
    var highestKey:String = ""
    
    //averagePrice is a double that is used to store the value of the calculated average to be printed out.
    var averagePrice:Double = 0.0
    //sum holds the value of all of the items in the dictionary sumed into one value to be calculated into the average.
    var sum:Double = 0.0
    
    //The for loop loops through all of the items in the dict and depending on the input proccesses them.
    for (_, product) in products.enumerated(){
        //The if statements will only run if they are required to run except sum which will be the default if the first two do not match.
        
        if(product.value<lowestValue && work=="lowest"){
            /*
            The first if compares if the value currently stored in lowestValue is greater than the element currently being inspected
            if the lowestValue is greater than the current element lowestValue and lowestKey are replaced with the current eleemnts value and key.
            */
            lowestKey = product.key
            lowestValue = product.value
        }else if(product.value>highestValue && work=="highest"){
            /*
             The else if statemnt compares the current element with the highestValue variable and if the current element is greater
             the highest variables are replaced with the current element.
             */
            highestKey = product.key
            highestValue = product.value
        }else{
            /*
             Finally the else statment adds the current element value to the sum.
             */
            sum += product.value
        }
        
        
    }
    
    //Depeding on the work string passed in the function will print out the specific information.
    if(work=="lowest"){
        //If "lowest" is passed in the function will print out the lowest variables values
        print("The product with the lowest value is \(lowestKey) with a value of \(lowestValue)")
    }else if(work=="highest"){
        //If "highest" is passed in the function will print out the highest variables values
        print("The product with the highest value is \(highestKey) with a value of \(highestValue)")
    }else if(work=="average"){
        //If "average" is passed in the function will print out the lowest variables values
        //average price is calculated just before printing to the screen
        //average is calculated based on the sum of all values divided by the total number of products in the list rather than a static number
        averagePrice = sum / Double(products.count)
        print("The average value of all products is \(averagePrice)")
    }
}
//These are the function calls that run dictFunc each with a different output
dictFunc(work: "lowest")
dictFunc(work: "highest")
dictFunc(work: "average")
