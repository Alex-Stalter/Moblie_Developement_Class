import UIKit

class Person
{
    var email = ""
    var name = ""
    init(email : String , name : String)
    {
        self.email = email
        self.name = name
    }
    
    func display()->String
    {
        return "Name: \(name) Email: \(email)"
    }
}


class Student: Person
{
    var gpa : Double
    
    init(nameS : String , emailS : String , gpa : Double)
    {
        self.gpa = gpa
        super.init(email: emailS, name: nameS)
    }
    
    override func display()->String
    {
        return super.display() + " GPA: \(gpa)"
    }
}

class Employee : Person
{
    init(nameE : String , emailE : String)
    {
        super.init(email: emailE, name: nameE)
    }
}

func generalDisplay(_ Person : Person)
{
    print(Person.display())
}

let person1 = Person(email: "astalter@bridgew.edu", name: "Alex")
let student1 = Student(nameS: "Matt", emailS: "matt@gmail.com", gpa: 4.0)

generalDisplay(person1)
generalDisplay(student1)
