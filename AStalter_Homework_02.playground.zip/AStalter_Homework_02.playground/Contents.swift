import UIKit
/*
 Author: Alex Stalter
 Date: 2/18/2020
 Class: COMP 399-001 Mobile App Developement
 
 The purpose of this code is to preform the highest and lowest functions on a given dictionary.
 Currently there are three functions lowestPrice, highestPrice, and price.
 lowestPrice and highestPrice run through a given dictionary that is passed in and return the respective name and value of either the lowest or highest element.
 price is a gernarl print function as it takes in a dictionary and a reference to a given function and prints out the return value.
 */

//foodDict is a global variable that is passed in to all three functions in order to find lowest and highest values and print them out
var foodDict: [String : (String, Double)] = ["Cake":("Desert",5.0),"Pizza":("Entre",3.0),"Hamburger":("Entre",2.5), "Fries":("Side",1.0),"Chips":("Side",0.5)]

//lowestPrice takes in a dictionary of the form [String : (String, Double)] and returns the name and value of the lowest valued item
func lowestPrice(_ dict : [String : (String, Double)]) -> (name : String, value : Double)
{
    //lowestVlaue is used as a comparitor to each of hte elements in the dictionary initilized at 100.0 becasue all of the items are lower in vlaue than 100.0
    var lowestValue : Double = 100.0
    //lowestName is a place holder and when an item is found that is lower than the current item it will be overwritten to hold the new loest value
    var lowestName : String = ""
    
    //This for loop goes through all of the items in the list and compares their value to the value of the current lowest item and if it is lower overwrites the current lowest
    for (k,v) in foodDict
    {
        if(v.1<lowestValue)
        {
            //this if stateent compares the current lowest with the value of hte item and if it is lower overwrites the current lowest with the current element being inspected
            lowestValue = v.1
            lowestName = k
        }
    }
    
    return (lowestName,lowestValue)
}
//highestPrice takes in a dictionary of the form [String : (String, Double)] and returns the highest value and name of the element
func highestPrice(_ dict : [String : (String, Double)]) -> (name:String, value:Double)
{
    //highestVal is initialized to 0.0 becasue all elements wil be larger than 0.0 will be overwritten with the current highest when a new higher value is found
    var highestVal: Double = 0.0
    //highestName is used as a place holder for the current highest element ad will be overwritten when a new highest is found
    var highestName: String = ""
    //this for loop goes through all of the elements in the given dictionary
    for (k,v) in dict
    {
        //This if sttement compares the current highest value to the value of the element being inspected currently and if it is a higher will overwrite the current highest with thecurrent elements value and name
        if(v.1>highestVal)
        {
            highestVal = v.1
            highestName = k
        }
    }
    return (highestName,highestVal)
}

//price takes in a dictionary of the form [String : (String, Double)] and a fucntion of form (_ dict : [String : (String, Double)]) -> (name:String, value:Double)
func price(_ dict : [String : (String, Double)],_ priceFunc : (_ dict : [String : (String, Double)]) -> (name:String, value:Double))
{
    //This print statment uses the parameters passed in to print out ether the lowest or highest price of an element in a given dictionary depending of the func passed in
    print("\(priceFunc(dict).name) with value of $\(priceFunc(dict).value)")
}

price(foodDict,highestPrice(_:))
price(foodDict,lowestPrice(_:))
